var e={viewport:"reset",viewportRotated:!1};export{e as globals};
